import React, { useState, useEffect } from 'react';
import { Lock, User, ShieldCheck, ArrowRight, AlertTriangle, KeyRound, Trophy } from 'lucide-react';
import { User as UserType } from '../types';

interface LoginProps {
  onLogin: (user: UserType) => void;
}

export const Login: React.FC<LoginProps> = ({ onLogin }) => {
  const [isSignUp, setIsSignUp] = useState(false);
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [error, setError] = useState('');
  const [successMsg, setSuccessMsg] = useState('');

  useEffect(() => {
    setError('');
    setSuccessMsg('');
    setUsername('');
    setPassword('');
    setConfirmPassword('');
  }, [isSignUp]);

  const handleAuth = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccessMsg('');

    if (!username || !password) {
      setError('Credentials Required');
      return;
    }

    const storedUsers = JSON.parse(localStorage.getItem('esports_users') || '[]');

    if (isSignUp) {
      if (password !== confirmPassword) {
        setError('Password Mismatch');
        return;
      }
      if (storedUsers.find((u: any) => u.username === username)) {
        setError('User Already Exists');
        return;
      }

      const newUser = { username, password };
      storedUsers.push(newUser);
      localStorage.setItem('esports_users', JSON.stringify(storedUsers));
      
      setSuccessMsg('Account Created Successfully');
      setTimeout(() => setIsSignUp(false), 1500);
    } else {
      const user = storedUsers.find((u: any) => u.username === username && u.password === password);
      if (user) {
        onLogin({ username: user.username });
      } else {
        setError('Invalid Username or Password');
      }
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-pro-main relative overflow-hidden font-sans">
      {/* Background Ambience */}
      <div className="absolute inset-0 bg-hex-pattern opacity-30 pointer-events-none"></div>
      <div className="absolute top-0 w-full h-1 bg-gradient-to-r from-transparent via-gold to-transparent opacity-50"></div>
      
      {/* Glow Effects */}
      <div className="absolute top-1/4 right-1/4 w-64 h-64 bg-pro-blue/10 rounded-full blur-[100px]"></div>
      <div className="absolute bottom-1/4 left-1/4 w-64 h-64 bg-gold/5 rounded-full blur-[100px]"></div>

      <div className="relative z-10 w-full max-w-md p-6">
        
        {/* Main Card */}
        <div className="bg-pro-card border border-pro-border rounded-lg shadow-2xl overflow-hidden relative group">
          {/* Top Gold Bar */}
          <div className="h-1 w-full bg-gradient-to-r from-gold/50 via-gold to-gold/50"></div>
          
          <div className="p-10 relative z-10">
            
            {/* Header */}
            <div className="text-center mb-10">
               <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-gradient-to-b from-pro-light to-pro-main border border-gold/30 mb-4 shadow-lg shadow-gold/10">
                  <Trophy className="w-8 h-8 text-gold" />
               </div>
               <h1 className="font-display font-bold text-5xl text-white uppercase tracking-tight">
                 ESPORTS<span className="text-gradient-gold">PRO</span>
               </h1>
               <p className="text-pro-text text-xs font-mono uppercase tracking-[0.3em] mt-2">
                 Official League Terminal
               </p>
            </div>

            <form onSubmit={handleAuth} className="space-y-6">
               
               {successMsg && (
                 <div className="bg-green-500/10 border border-green-500/30 p-3 rounded text-green-400 text-xs font-mono flex gap-2 items-center justify-center">
                   <ShieldCheck className="w-4 h-4" /> {successMsg}
                 </div>
               )}

               {error && (
                 <div className="bg-red-500/10 border border-red-500/30 p-3 rounded text-red-400 text-xs font-mono flex gap-2 items-center justify-center">
                   <AlertTriangle className="w-4 h-4" /> {error}
                 </div>
               )}

               <div className="space-y-4">
                 <div className="group">
                   <label className="block text-[10px] uppercase font-bold text-pro-text mb-1 ml-1 group-focus-within:text-gold transition-colors">Username / ID</label>
                   <div className="relative">
                     <div className="absolute left-3 top-3 text-pro-text group-focus-within:text-white transition-colors">
                       <User className="w-5 h-5" />
                     </div>
                     <input 
                       type="text" 
                       value={username}
                       onChange={(e) => setUsername(e.target.value)}
                       className="w-full bg-pro-light/50 border border-pro-border rounded p-3 pl-10 text-white font-mono placeholder:text-pro-text/30 focus:border-gold focus:bg-pro-light focus:ring-1 focus:ring-gold/50 outline-none transition-all"
                       placeholder="ENTER ID"
                     />
                   </div>
                 </div>

                 <div className="group">
                   <label className="block text-[10px] uppercase font-bold text-pro-text mb-1 ml-1 group-focus-within:text-gold transition-colors">Password</label>
                   <div className="relative">
                     <div className="absolute left-3 top-3 text-pro-text group-focus-within:text-white transition-colors">
                       <Lock className="w-5 h-5" />
                     </div>
                     <input 
                       type="password" 
                       value={password}
                       onChange={(e) => setPassword(e.target.value)}
                       className="w-full bg-pro-light/50 border border-pro-border rounded p-3 pl-10 text-white font-mono placeholder:text-pro-text/30 focus:border-gold focus:bg-pro-light focus:ring-1 focus:ring-gold/50 outline-none transition-all"
                       placeholder="••••••••"
                     />
                   </div>
                 </div>

                 {isSignUp && (
                   <div className="group animate-slide-up">
                     <label className="block text-[10px] uppercase font-bold text-pro-text mb-1 ml-1 group-focus-within:text-gold transition-colors">Confirm Password</label>
                     <div className="relative">
                       <div className="absolute left-3 top-3 text-pro-text group-focus-within:text-white transition-colors">
                         <KeyRound className="w-5 h-5" />
                       </div>
                       <input 
                         type="password" 
                         value={confirmPassword}
                         onChange={(e) => setConfirmPassword(e.target.value)}
                         className="w-full bg-pro-light/50 border border-pro-border rounded p-3 pl-10 text-white font-mono placeholder:text-pro-text/30 focus:border-gold focus:bg-pro-light focus:ring-1 focus:ring-gold/50 outline-none transition-all"
                         placeholder="••••••••"
                       />
                     </div>
                   </div>
                 )}
               </div>

               <button 
                 type="submit"
                 className="w-full bg-gradient-to-r from-gold to-yellow-500 hover:from-yellow-400 hover:to-yellow-600 text-black font-display font-bold text-xl uppercase tracking-widest py-3 rounded shadow-lg shadow-gold/20 transform transition-all hover:-translate-y-0.5 active:translate-y-0"
               >
                 <div className="flex items-center justify-center gap-2">
                   {isSignUp ? 'Register Account' : 'Secure Login'} <ArrowRight className="w-5 h-5" />
                 </div>
               </button>
            </form>

            <div className="mt-8 pt-6 border-t border-pro-border text-center">
              <button 
                onClick={() => setIsSignUp(!isSignUp)}
                className="text-xs font-mono font-bold uppercase text-pro-text hover:text-white transition-colors"
              >
                {isSignUp ? 'Already have an account? Login' : 'New User? Create Account'}
              </button>
            </div>

          </div>
        </div>
        
        {/* Footer */}
        <div className="text-center mt-6">
           <p className="text-[10px] text-pro-text uppercase tracking-widest opacity-50">
             &copy; 2025 Esports Pro League. All Rights Reserved.
           </p>
        </div>

      </div>
    </div>
  );
};