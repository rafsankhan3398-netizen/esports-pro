import { GoogleGenAI } from "@google/genai";
import { Team } from '../types';

export const analyzeTournament = async (teams: Team[]): Promise<string> => {
  try {
    // Guideline: The API key must be obtained exclusively from the environment variable process.env.API_KEY
    // and used directly when initializing the client instance.
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    
    // Sort teams by points for better context
    const sortedTeams = [...teams].sort((a, b) => b.stats.points - a.stats.points);
    
    const teamContext = sortedTeams.map(t => 
      `Rank ${t.stats.position}: ${t.name} (Points: ${t.stats.points}, Wins: ${t.stats.wins}, Players: ${t.players.map(p => p.name).join(', ')})`
    ).join('\n');

    const prompt = `
      You are a professional Esports Analyst and Caster. 
      Analyze the current tournament standings provided below.
      
      Tournament Data:
      ${teamContext}

      Provide a high-energy, exciting summary of the tournament so far. 
      - Highlight the leading team.
      - Mention any potential underdogs.
      - Predict which team has the best momentum based on wins/points.
      - Keep it under 200 words.
      - Use gaming terminology (e.g., "meta", "carry", "clutch").
    `;

    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
    });

    return response.text || "Could not generate analysis.";
  } catch (error) {
    console.error("Gemini Error:", error);
    return "VIP Analysis System Offline. Please check API Key connection.";
  }
};